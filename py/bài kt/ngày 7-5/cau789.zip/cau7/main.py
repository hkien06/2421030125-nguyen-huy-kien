import cau7 as module

module.cau7()
