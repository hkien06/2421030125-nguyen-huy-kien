def cau8():
    x = int(input("Nhap x: "))
    y = int(input("Nhap y: "))
    z = int(input("Nhap z: "))

    dem = 0
    max = 0
    tich = x * y * z
    print("Tich =", tich)

    while tich > 0:
        cs = tich % 10
        dem = dem + 1
        if cs > max:
            max = cs
        tich = tich // 10

    print("So chu so =", dem)
    print("Chu so lon nhat =", max)
