import cau8 as module

module.cau8()
