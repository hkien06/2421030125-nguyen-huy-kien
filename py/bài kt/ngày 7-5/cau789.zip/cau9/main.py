import cau9 as module

module.cau9()
